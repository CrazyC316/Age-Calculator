﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_age
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_name = New System.Windows.Forms.Label()
        Me.lbl_year = New System.Windows.Forms.Label()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.btn_calc = New System.Windows.Forms.Button()
        Me.lbl_output = New System.Windows.Forms.Label()
        Me.ListBox_DOB = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lbl_name
        '
        Me.lbl_name.AutoSize = True
        Me.lbl_name.Location = New System.Drawing.Point(44, 20)
        Me.lbl_name.Name = "lbl_name"
        Me.lbl_name.Size = New System.Drawing.Size(63, 13)
        Me.lbl_name.TabIndex = 0
        Me.lbl_name.Text = "Enter Name"
        '
        'lbl_year
        '
        Me.lbl_year.AutoSize = True
        Me.lbl_year.Location = New System.Drawing.Point(179, 20)
        Me.lbl_year.Name = "lbl_year"
        Me.lbl_year.Size = New System.Drawing.Size(87, 13)
        Me.lbl_year.TabIndex = 1
        Me.lbl_year.Text = "Enter year of bith"
        '
        'txt_name
        '
        Me.txt_name.Location = New System.Drawing.Point(12, 41)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(126, 20)
        Me.txt_name.TabIndex = 2
        '
        'btn_calc
        '
        Me.btn_calc.Location = New System.Drawing.Point(12, 75)
        Me.btn_calc.Name = "btn_calc"
        Me.btn_calc.Size = New System.Drawing.Size(269, 24)
        Me.btn_calc.TabIndex = 4
        Me.btn_calc.Text = "Calculate"
        Me.btn_calc.UseVisualStyleBackColor = True
        '
        'lbl_output
        '
        Me.lbl_output.AutoSize = True
        Me.lbl_output.Location = New System.Drawing.Point(15, 110)
        Me.lbl_output.Name = "lbl_output"
        Me.lbl_output.Size = New System.Drawing.Size(0, 13)
        Me.lbl_output.TabIndex = 5
        '
        'ListBox_DOB
        '
        Me.ListBox_DOB.FormattingEnabled = True
        Me.ListBox_DOB.Items.AddRange(New Object() {"2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950"})
        Me.ListBox_DOB.Location = New System.Drawing.Point(168, 39)
        Me.ListBox_DOB.Name = "ListBox_DOB"
        Me.ListBox_DOB.Size = New System.Drawing.Size(113, 30)
        Me.ListBox_DOB.TabIndex = 6
        '
        'form_age
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(307, 134)
        Me.Controls.Add(Me.ListBox_DOB)
        Me.Controls.Add(Me.lbl_output)
        Me.Controls.Add(Me.btn_calc)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.lbl_year)
        Me.Controls.Add(Me.lbl_name)
        Me.Name = "form_age"
        Me.Text = "Age Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_name As Label
    Friend WithEvents lbl_year As Label
    Friend WithEvents txt_name As TextBox
    Friend WithEvents btn_calc As Button
    Friend WithEvents lbl_output As Label
    Friend WithEvents ListBox_DOB As ListBox

    Private Sub btn_calc_Click(sender As Object, e As EventArgs) Handles btn_calc.Click

    End Sub
End Class
