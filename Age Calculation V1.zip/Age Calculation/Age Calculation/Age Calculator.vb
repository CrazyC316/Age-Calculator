﻿Public Class form_age
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txt_name.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_calc.Click
        Dim thisYear As Integer
        thisYear = System.DateTime.Now.Year

        Dim DOByear As Integer
        DOByear = thisYear.ToString - listbox_DOB.Text

        Dim name As String
        name = txt_name.Text

        lbl_output.Text = "Hello " & name & ",You have been alive for " & DOByear & " Years"
    End Sub
End Class
